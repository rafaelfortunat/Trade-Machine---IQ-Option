from iqoptionapi.stable_api import IQ_Option
import time
from configobj import ConfigObj
import json, sys
from datetime import datetime

# Insira seu e-mail e senha aqui

config = ConfigObj('config.txt')
email = config['LOGIN']['email']
password = config['LOGIN']['senha']
tipo = config['AJUSTES']['tipo']
valor_entrada = float(config['AJUSTES']['valor_entrada'])
stop_win = float(config['AJUSTES']['stop_win'])
stop_loss = float(config['AJUSTES']['stop_loss'])
lucro_total = 0
qtd_win = 0
qtd_loss = 0
qtd_empate = 0
stop = True


if config['MARTINGALE']['usar_martingale']:
    martingale = int(config['MARTINGALE']['niveis_martingale'])
else:
    martingale = 0

fator_martingale = float(config['MARTINGALE']['fator_martingale'])


API = IQ_Option(email, password)


# Função para conectar ao IQ Option
check, reason = API.connect()
if check:
    print('\nConectado ao IQ Option com sucesso!')
else:
    if reason == '{"code":"invalid_credentials","message":"You entered the wrong credentials. Please ensure that your login/password is correct."}':
        print('\nFalha ao logar > E-mail ou senha inválido')
        sys.exit()
    else:
        print(f'\nHouve um problema na conexão\nMotivo: {reason}')
        sys.exit()

# Função para selecionar o tipo de conta (Real ou Demo)
while True:
    #escolha = input('\nSelecione a conta em que deseja conectar (demo ou real): ')
    escolha = config['AJUSTES']['tipo_conta']
    if escolha == 'demo':
        conta = 'PRACTICE'
        print('Conta DEMO selecionada')
        break
    if escolha == 'real':
        conta = 'REAL'
        print('\nConta REAL selecionada. CUIDADO COM SUAS OPERAÇÕES REAIS!!')
        break
    else:
        print('\nOpção incorreta. Escolha as opções "demo" ou "real" para continuar: ')

API.change_balance(conta)


# Função para checar stop_win e stop_loss
def check_stop():
    global stop, lucro_total
    if lucro_total <= float('-'+str(abs(stop_loss))):
        stop = False
        print('\n#####################################################################')
        print(f'Stop Loss atingido {str(cifrao)}{str(lucro_total)}')
        print('#####################################################################')
        sys.exit()

    if lucro_total >= float(abs(stop_win)):
        stop = False
        print('\n#####################################################################')
        print(f'Stop Win atingido {str(cifrao)}{str(lucro_total)}')
        print('#####################################################################')
        sys.exit()

# Função de abrir ordem e checar resultado
def compra(ativo, valor_entrada, direcao, exp, tipo):
    
    global stop, lucro_total, qtd_win, qtd_empate, qtd_loss

    entrada = valor_entrada

    for i in range(martingale + 1):

        if stop == True:

            if tipo == 'digital':
                check, id = API.buy_digital_spot_v2(ativo, entrada, direcao, exp)
            else:
                check, id = API.buy(entrada, ativo, direcao, exp)

            if check:

                if i == 0:
                    print(f'\n>> Ordem em aberto - ID: {id}\nPar: {ativo}\nTimeframe: {exp}\nValor de entrada: {cifrao}{entrada}')
                if i >= 1:
                    print(f'\n>> Ordem em aberto para o gale {str(i)} - ID: {id}\nPar: {ativo}\nTimeframe: {exp}\nValor de entrada: {cifrao}{entrada}')


                while True:
                    time.sleep(0.1)
                    status, resultado = API.check_win_digital_v2(id) if tipo == 'digital' else API.check_win_v4(id)

                    if status:

                        lucro_total += round(resultado,2)

                        if resultado > 0:
                            qtd_win += 1
                            if i == 0:
                                print(f'\n>> Resultado: Você obteve GANHO de {cifrao}{round(resultado,2)}\n>> Par: {ativo}\n>> Lucro total: {cifrao}{round(lucro_total,2)}\nWins: {qtd_win}\nLoss: {qtd_loss}\nEmpates: {qtd_empate}\n>> Novo saldo: {cifrao}{float(API.get_balance())}')
                            if i >= 1:
                                print(f'\n>> Resultado: Você obteve GANHO de {cifrao}{round(resultado,2)} no Gale de nº{i}\n>> Par: {ativo}\n>> Lucro total: {cifrao}{round(lucro_total,2)}\nWins: {qtd_win}\nLoss: {qtd_loss}\nEmpates: {qtd_empate}\n>> Novo saldo: {cifrao}{float(API.get_balance())}')

                        elif resultado == 0:
                            qtd_empate += 1
                            if i == 0:
                                print(f'\n>> Resultado: Você obteve EMPATE em sua ordem (resultado: {cifrao}{round(resultado,2)})\n>> Par: {ativo}\n>> Lucro total: {cifrao}{round(lucro_total,2)}\nWins: {qtd_win}\nLoss: {qtd_loss}\nEmpates: {qtd_empate}\n>> Novo saldo: {cifrao}{float(API.get_balance())}')
                            if i >= 1:
                                print(f'\n>> Resultado: Você obteve EMPATE de {cifrao}{round(resultado,2)} no Gale de nº{i}\n>> Par: {ativo}\n>> Lucro total: {cifrao}{round(lucro_total,2)}\nWins: {qtd_win}\nLoss: {qtd_loss}\nEmpates: {qtd_empate}\n>> Novo saldo: {cifrao}{float(API.get_balance())}')
                            
                            if i+1 <= martingale:
                                gale = float(entrada)
                                entrada = round(abs(gale),2)

                        else:
                            if i == 0:
                                print(f'\n>> Resultado: Você obteve PERDA de {cifrao}{round(resultado,2)}\n>> Par: {ativo}\n>> Lucro total: {cifrao}{round(lucro_total,2)}\nWins: {qtd_win}\nLoss: {qtd_loss}\nEmpates: {qtd_empate}\n>> Novo saldo: {cifrao}{float(API.get_balance())}')
                            if i >= 1:
                                if i+1 > martingale:
                                    qtd_loss += 1
                                else:
                                    pass
                                print(f'\n>> Resultado: Você obteve PERDA de {cifrao}{round(resultado,2)} no Gale de nº{i}\n>> Par: {ativo}\n>> Lucro total: {cifrao}{round(lucro_total,2)}\nWins: {qtd_win}\nLoss: {qtd_loss}\nEmpates: {qtd_empate}\n>> Novo saldo: {cifrao}{float(API.get_balance())}')        
                            if i+1 <= martingale:
                                gale = float(entrada) * float(fator_martingale)
                                entrada = round(abs(gale),2)
                                

                        check_stop()
                        break
                
                if resultado > 0:
                    break

            else:
                print(f'Erro na tentativa de execultar a order de ID {id}.')


def estrategia_mhi():
    while True:
        time.sleep(0.1)

        # Horário do computador (desabilitar horário do servidor IQ Option caso queira utilizar esta opção)
        minutos = float(datetime.now().strftime('%M.%S')[1:])

        # Horário do servidor IQ Option (recomendado)
        minutos = float(datetime.fromtimestamp(API.get_server_timestamp()).strftime('%M.%S')[1:])

        entrar = True if (minutos >= 4.59 and minutos <= 5.00) or minutos >= 9.59 else False
        print('Aguardando horário de entrada.', minutos, end = '\r')

        if entrar:
            print('\n>> Iniciando análise de estratégia MHI')

            direcao = False
            timeframe = 60
            qtd_velas = 3

            velas = API.get_candles(ativo, timeframe, qtd_velas, time.time())

            velas[0] = 'Verde' if velas[0]['open'] < velas[0]['close'] else 'Vermelha' if velas[0]['open'] > velas[0]['close'] else 'Doji'
            velas[1] = 'Verde' if velas[1]['open'] < velas[1]['close'] else 'Vermelha' if velas[1]['open'] > velas[1]['close'] else 'Doji'
            velas[2] = 'Verde' if velas[2]['open'] < velas[2]['close'] else 'Vermelha' if velas[2]['open'] > velas[2]['close'] else 'Doji'

            cores = velas[0], velas[1], velas[2]

            if cores.count('Verde') > cores.count('Vermelha') and cores.count('Doji') == 0: direcao = 'put'
            if cores.count('Verde') < cores.count('Vermelha') and cores.count('Doji') == 0: direcao = 'call'

            if direcao:
                print(f'Velas: {velas[0]}, {velas[1]}, {velas[2]} - Entrada definida para {direcao}')
            
                compra(ativo, valor_entrada, direcao, 1, tipo)
            
            else:
                print(f'Velas: {velas[0]}, {velas[1]}, {velas[2]}')
                print('Entrada abortada - Foi encontrado um ou mais Dojis na análise')
                time.sleep(2)

            print('\n#####################################################################\n')

# Definição dos imputs iniciais do robô
ativo = input('Digite o ativo que deseja operar (ex.: EURUSD): ').upper()
#exp = input('\n >> Qual timeframe de operação (segundos)?: ')
#direcao = input('\n >> Entrada para Call (Acima) ou Put (Abaixo)?: ').lower()

perfil = json.loads(json.dumps(API.get_profile_ansyc()))
cifrao = str(perfil['currency_char'])
nome = str(perfil['name'])

valor_conta = float(API.get_balance())

print('\n#####################################################################\n')
print(f'\n\nOlá {nome}!')
print(f'\nSeu saldo atual na conta {escolha} é de {cifrao}{valor_conta}')
print(f'\nSeu valor de entrada pré-definido é de {cifrao}{valor_entrada}')
print(f'\nStop Win definido: {cifrao}{stop_win}')
print(f'\nStop Loss definido: -{cifrao}{stop_loss}')
print('\n#####################################################################\n\n')


# Chamada da função de compra
#compra(ativo, valor_entrada, direcao, exp, tipo)

# Chamada da função de estratégia MHI
estrategia_mhi()